package libsvm;
public interface svm_print_interface
{
	public void print(String s);
}
