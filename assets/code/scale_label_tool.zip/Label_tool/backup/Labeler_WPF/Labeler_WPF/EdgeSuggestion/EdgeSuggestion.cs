﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;
using ImageProcessing;
using Util;
using System.Windows.Ink;

namespace Labeler_WPF.EdgeSuggestion
{
    class CEdgeSuggestion
    {
        private string imgFilePath;
        
        private Bitmap img;
        private int scale;

        private int imgHeight;
        private int imgWidth;

        public static int octave = 5;
        public int[,] gradMap;

        public CEdgeSuggestion(string imgPath, int scale = 0)
        {
            this.imgFilePath = imgPath;
            this.scale = scale;
            //Read Image
            initialImg();

            computeGradient();
        }

        private bool initialImg()
        {
            try
            {
                Bitmap originalImg = (Bitmap)Bitmap.FromFile(imgFilePath);

                int resizeRatio = Convert.ToInt32(Math.Pow(2, octave - this.scale - 1));
                //resize to the input scale
                img = new Bitmap(originalImg, originalImg.Width / resizeRatio, originalImg.Height / resizeRatio);
                this.imgHeight = img.Height;
                this.imgWidth = img.Width;

                this.gradMap = new int[imgWidth, imgHeight];

                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Compute first order gradient, convoled by Gaussian, 
        /// With non-maximal supression
        /// </summary>
        /// <param name="sigma">By default, it is 1.0</param>
        public void computeGradient(float sigma = 0.5f)
        {
            CannyEdgeDetector detector = new CannyEdgeDetector();
            int gaussianKernelWidth = (int)(8 * sigma);
            int[] grad = detector.UpdateGradient(this.img, sigma, gaussianKernelWidth);

            array2matrix(grad);

            #region "Test"
            ////for test
            //Bitmap gradImg = new Bitmap(imgWidth, imgHeight);
            //for (int i = 0; i < imgWidth; i++)
            //{
            //    for (int j = 0; j < imgHeight; j++)
            //    {
            //        gradImg.SetPixel(i,j,Color.FromArgb(gradMap[i,j],gradMap[i,j],gradMap[i,j]));
            //    }
            //}
            //gradImg.Save(scale.ToString() + ".jpg");
            #endregion
        }

        private void array2matrix(int[] gradData)
        {
            for (int y = 0; y < imgHeight; y++)
            {
                for (int x = 0; x < imgWidth; x++)
                {
                    gradMap[x, y] = gradData[y * imgWidth + x];
                }
            }
        }

        public Stroke suggestStroke(Stroke inputStroke, int distThresh, float[] weight)
        {
            Stroke newStroke = new Stroke(inputStroke.StylusPoints);

            /*******************************************************************************/
            //Optimization target function:
            //Since all gradient is normalized to 0-255
            //So the target is to Max{w1 * gradient - w2 * location shift}
            //The optimization is performed pixel-wisely
            /******************************************************************************/
            for (int i = 0; i < newStroke.StylusPoints.Count; i++)
            {
                int x = (int)(newStroke.StylusPoints[i].X);
                int y = (int)(newStroke.StylusPoints[i].Y);

                //Just move y (vertically)
                double[] values = new double[2 * distThresh + 1];
                double maxValue = 0.0;
                int maxY = y - distThresh;
                for (int dy = 0; dy < 2 * distThresh + 1; dy++)
                {
                    int y2 = y-distThresh + dy;
                    if (y2 < 0 || y2 >= imgHeight)
                    {
                        values[dy] = 0;
                        continue;
                    }
                    values[dy] = weight[0] * gradMap[x, y2] - weight[1] * Math.Abs(dy);
                    if (values[dy] > maxValue)
                    {
                        maxValue = values[dy];
                        maxY = y2;
                    }
                }

                newStroke.StylusPoints[i] = new System.Windows.Input.StylusPoint(x, maxY);
            }
            return newStroke;
        }
    }
}
