﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Imaging;
using Util;


namespace ImageProcessing.Filters
{
    public class BaseFilter
    {
        // convolution kernel
        private int[,] kernel;
        // division factor
        private int divisor = 1;
        // threshold to add to weighted sum
        private int threshold = 0;
        // kernel size
        private int size;
        // use dynamic divisor for edges
        private bool dynamicDivisorForEdges = true;

        #region "Constructors"
        protected BaseFilter()
        {
            
        }

        public BaseFilter(int[,] kernel)
            : this()
        {
            Kernel = kernel;

            divisor = 0;

            // calculate divisor
            for ( int i = 0, n = kernel.GetLength( 0 ); i < n; i++ )
            {
                for ( int j = 0, k = kernel.GetLength( 1 ); j < k; j++ )
                {
                    divisor += kernel[i, j];
                }
            }
            if ( divisor == 0 )
                divisor = 1;
        }

        public BaseFilter(int[,] kernel, int divisor)
            : this()
        {
            Kernel = kernel;
            Divisor = divisor;
        }
        #endregion


        #region "Properties"
        public int[,] Kernel
        {
            get { return kernel; }
            set
            {
                int s = value.GetLength(0);

                // check kernel size
                if ((s != value.GetLength(1)) || (s < 3) || (s > 99) || (s % 2 == 0))
                    throw new ArgumentException("Invalid kernel size.");

                this.kernel = value;
                this.size = s;
            }
        }

        /// <summary>
        /// Division factor.
        /// </summary>
        ///
        /// <remarks><para>The value is used to divide convolution - weighted sum
        /// of pixels is divided by this value.</para>
        ///
        /// <para><note>The value may be calculated automatically in the case if constructor
        /// with one parameter is used (<see cref="Convolution( int[,] )"/>).</note></para>
        /// </remarks>
        ///
        /// <exception cref="ArgumentException">Divisor can not be equal to zero.</exception>
        ///
        public int Divisor
        {
            get { return divisor; }
            set
            {
                if (value == 0)
                    throw new ArgumentException("Divisor can not be equal to zero.");
                divisor = value;
            }
        }

        /// <summary>
        /// Threshold to add to weighted sum.
        /// </summary>
        ///
        /// <remarks><para>The property specifies threshold value, which is added to each weighted
        /// sum of pixels. The value is added right after division was done by <see cref="Divisor"/>
        /// value.</para>
        ///
        /// <para>Default value is set to <b>0</b>.</para>
        /// </remarks>
        ///
        public int Threshold
        {
            get { return threshold; }
            set { threshold = value; }
        }


        /// <summary>
        /// Use dynamic divisor for edges or not.
        /// </summary>
        ///
        /// <remarks><para>The property specifies how to handle edges. If it is set to
        /// <see langword="false"/>, then the same divisor (which is specified by <see cref="Divisor"/>
        /// property or calculated automatically) will be applied both for non-edge regions
        /// and for edge regions. If the value is set to <see langword="true"/>, then dynamically
        /// calculated divisor will be used for edge regions, which is sum of those kernel
        /// elements, which are taken into account for particular processed pixel
        /// (elements, which are not outside image).</para>
        ///
        /// <para>Default value is set to <see langword="true"/>.</para>
        /// </remarks>
        ///
        public bool DynamicDivisorForEdges
        {
            get { return dynamicDivisorForEdges; }
            set { dynamicDivisorForEdges = value; }
        }

        #endregion

        #region "Operation"
        public Bitmap Apply(Bitmap image)
        {
            // lock source bitmap data
            BitmapData srcData = image.LockBits(
                new Rectangle(0, 0, image.Width, image.Height),
                ImageLockMode.ReadOnly, image.PixelFormat);

            Bitmap dstImage = null;

            try
            {
                // apply the filter
                dstImage = Apply(srcData);
            }
            finally
            {
                // unlock source image
                image.UnlockBits(srcData);
            }

            return dstImage;
        }

        /// <summary>
        /// Apply filter to an image.
        /// </summary>
        ///
        /// <param name="imageData">Source image to apply filter to.</param>
        ///
        /// <returns>Returns filter's result obtained by applying the filter to
        /// the source image.</returns>
        ///
        /// <remarks>The filter accepts bitmap data as input and returns the result
        /// of image processing filter as new image. The source image data are kept
        /// unchanged.</remarks>
        ///
        /// <exception cref="UnsupportedImageFormatException">Unsupported pixel format of the source image.</exception>
        ///
        public Bitmap Apply(BitmapData imageData)
        {
            // get width and height
            int width = imageData.Width;
            int height = imageData.Height;

            PixelFormat pFormat = imageData.PixelFormat;
            // create new image of required format
            Bitmap dstImage = new Bitmap(width, height, pFormat);

            // lock destination bitmap data
            BitmapData dstData = dstImage.LockBits(
                new Rectangle(0, 0, width, height),
                ImageLockMode.ReadWrite, pFormat);

            try
            {
                // process the filter
                ProcessFilter(new UnmanagedImage(imageData), new UnmanagedImage(dstData), new Rectangle(0, 0, width, height));
            }
            finally
            {
                // unlock destination images
                dstImage.UnlockBits(dstData);
            }

            return dstImage;
        }

        /// <summary>
        /// Apply filter to an image in unmanaged memory.
        /// </summary>
        ///
        /// <param name="image">Source image in unmanaged memory to apply filter to.</param>
        ///
        /// <returns>Returns filter's result obtained by applying the filter to
        /// the source image.</returns>
        ///
        /// <remarks>The method keeps the source image unchanged and returns
        /// the result of image processing filter as new image.</remarks>
        ///
        /// <exception cref="UnsupportedImageFormatException">Unsupported pixel format of the source image.</exception>
        ///
        public UnmanagedImage Apply(UnmanagedImage image, PixelFormat pFormat)
        {
            // create new destination image
            UnmanagedImage dstImage = UnmanagedImage.Create(image.Width, image.Height, pFormat);

            // process the filter
            ProcessFilter(image, dstImage, new Rectangle(0, 0, image.Width, image.Height));

            return dstImage;
        }

        /// <summary>
        /// Process the filter on the specified image.
        /// </summary>
        ///
        /// <param name="source">Source image data.</param>
        /// <param name="destination">Destination image data.</param>
        /// <param name="rect">Image rectangle for processing by the filter.</param>
        ///
        protected unsafe void ProcessFilter(UnmanagedImage source, UnmanagedImage destination, Rectangle rect)
        {
            int pixelSize = Image.GetPixelFormatSize(source.PixelFormat) / 8;

            // processing start and stop X,Y positions
            int startX = rect.Left;
            int startY = rect.Top;
            int stopX = startX + rect.Width;
            int stopY = startY + rect.Height;

            // loop and array indexes
            int i, j, t, k, ir, jr;
            // kernel's radius
            int radius = size >> 1;
            // color sums
            long r, g, b, div;

            // kernel size
            int kernelSize = size * size;
            // number of kernel elements taken into account
            int processedKernelSize;

            // check pixel size to find if we deal with 8 or 16 bpp channels
            if (pixelSize <= 4)
            {
                int srcStride = source.Stride;
                int dstStride = destination.Stride;

                int srcOffset = srcStride - rect.Width * pixelSize;
                int dstOffset = dstStride - rect.Width * pixelSize;

                byte* src = (byte*)source.ImageData.ToPointer();
                byte* dst = (byte*)destination.ImageData.ToPointer();
                byte* p;

                // allign pointers to the first pixel to process
                src += (startY * srcStride + startX * pixelSize);
                dst += (startY * dstStride + startX * pixelSize);

                // do the processing job
                if (destination.PixelFormat == PixelFormat.Format8bppIndexed)
                {
                    // grayscale image

                    // for each line
                    for (int y = startY; y < stopY; y++)
                    {
                        // for each pixel
                        for (int x = startX; x < stopX; x++, src++, dst++)
                        {
                            g = div = processedKernelSize = 0;

                            // for each kernel row
                            for (i = 0; i < size; i++)
                            {
                                ir = i - radius;
                                t = y + ir;

                                // skip row
                                if (t < startY)
                                    continue;
                                // break
                                if (t >= stopY)
                                    break;

                                // for each kernel column
                                for (j = 0; j < size; j++)
                                {
                                    jr = j - radius;
                                    t = x + jr;

                                    // skip column
                                    if (t < startX)
                                        continue;

                                    if (t < stopX)
                                    {
                                        k = kernel[i, j];

                                        div += k;
                                        g += k * src[ir * srcStride + jr];
                                        processedKernelSize++;
                                    }
                                }
                            }

                            // check if all kernel elements were processed
                            if (processedKernelSize == kernelSize)
                            {
                                // all kernel elements are processed - we are not on the edge
                                div = divisor;
                            }
                            else
                            {
                                // we are on edge. do we need to use dynamic divisor or not?
                                if (!dynamicDivisorForEdges)
                                {
                                    // do
                                    div = divisor;
                                }
                            }

                            // check divider
                            if (div != 0)
                            {
                                g /= div;
                            }
                            g += threshold;
                            *dst = (byte)((g > 255) ? 255 : ((g < 0) ? 0 : g));
                        }
                        src += srcOffset;
                        dst += dstOffset;
                    }
                }
                else
                {
                    // RGB image

                    // for each line
                    for (int y = startY; y < stopY; y++)
                    {
                        // for each pixel
                        for (int x = startX; x < stopX; x++, src += pixelSize, dst += pixelSize)
                        {
                            r = g = b = div = processedKernelSize = 0;

                            // for each kernel row
                            for (i = 0; i < size; i++)
                            {
                                ir = i - radius;
                                t = y + ir;

                                // skip row
                                if (t < startY)
                                    continue;
                                // break
                                if (t >= stopY)
                                    break;

                                // for each kernel column
                                for (j = 0; j < size; j++)
                                {
                                    jr = j - radius;
                                    t = x + jr;

                                    // skip column
                                    if (t < startX)
                                        continue;

                                    if (t < stopX)
                                    {
                                        k = kernel[i, j];
                                        p = &src[ir * srcStride + jr * pixelSize];

                                        div += k;

                                        r += k * p[RGB.R];
                                        g += k * p[RGB.G];
                                        b += k * p[RGB.B];

                                        processedKernelSize++;
                                    }
                                }
                            }

                            // check if all kernel elements were processed
                            if (processedKernelSize == kernelSize)
                            {
                                // all kernel elements are processed - we are not on the edge
                                div = divisor;
                            }
                            else
                            {
                                // we are on edge. do we need to use dynamic divisor or not?
                                if (!dynamicDivisorForEdges)
                                {
                                    // do
                                    div = divisor;
                                }
                            }

                            // check divider
                            if (div != 0)
                            {
                                r /= div;
                                g /= div;
                                b /= div;
                            }
                            r += threshold;
                            g += threshold;
                            b += threshold;

                            dst[RGB.R] = (byte)((r > 255) ? 255 : ((r < 0) ? 0 : r));
                            dst[RGB.G] = (byte)((g > 255) ? 255 : ((g < 0) ? 0 : g));
                            dst[RGB.B] = (byte)((b > 255) ? 255 : ((b < 0) ? 0 : b));

                            // take care of alpha channel
                            if (pixelSize == 4)
                                dst[RGB.A] = src[RGB.A];
                        }
                        src += srcOffset;
                        dst += dstOffset;
                    }
                }
            }
            else
            {
                pixelSize /= 2;

                int dstStride = destination.Stride / 2;
                int srcStride = source.Stride / 2;

                // base pointers
                ushort* baseSrc = (ushort*)source.ImageData.ToPointer();
                ushort* baseDst = (ushort*)destination.ImageData.ToPointer();
                ushort* p;

                // allign pointers by X
                baseSrc += (startX * pixelSize);
                baseDst += (startX * pixelSize);

                if (source.PixelFormat == PixelFormat.Format16bppGrayScale)
                {
                    // 16 bpp grayscale image

                    // for each line
                    for (int y = startY; y < stopY; y++)
                    {
                        ushort* src = baseSrc + y * srcStride;
                        ushort* dst = baseDst + y * dstStride;

                        // for each pixel
                        for (int x = startX; x < stopX; x++, src++, dst++)
                        {
                            g = div = processedKernelSize = 0;

                            // for each kernel row
                            for (i = 0; i < size; i++)
                            {
                                ir = i - radius;
                                t = y + ir;

                                // skip row
                                if (t < startY)
                                    continue;
                                // break
                                if (t >= stopY)
                                    break;

                                // for each kernel column
                                for (j = 0; j < size; j++)
                                {
                                    jr = j - radius;
                                    t = x + jr;

                                    // skip column
                                    if (t < startX)
                                        continue;

                                    if (t < stopX)
                                    {
                                        k = kernel[i, j];

                                        div += k;
                                        g += k * src[ir * srcStride + jr];
                                        processedKernelSize++;
                                    }
                                }
                            }

                            // check if all kernel elements were processed
                            if (processedKernelSize == kernelSize)
                            {
                                // all kernel elements are processed - we are not on the edge
                                div = divisor;
                            }
                            else
                            {
                                // we are on edge. do we need to use dynamic divisor or not?
                                if (!dynamicDivisorForEdges)
                                {
                                    // do
                                    div = divisor;
                                }
                            }

                            // check divider
                            if (div != 0)
                            {
                                g /= div;
                            }
                            g += threshold;
                            *dst = (ushort)((g > 65535) ? 65535 : ((g < 0) ? 0 : g));
                        }
                    }
                }
                else
                {
                    // for each line
                    for (int y = startY; y < stopY; y++)
                    {
                        ushort* src = baseSrc + y * srcStride;
                        ushort* dst = baseDst + y * dstStride;

                        // for each pixel
                        for (int x = startX; x < stopX; x++, src += pixelSize, dst += pixelSize)
                        {
                            r = g = b = div = processedKernelSize = 0;

                            // for each kernel row
                            for (i = 0; i < size; i++)
                            {
                                ir = i - radius;
                                t = y + ir;

                                // skip row
                                if (t < startY)
                                    continue;
                                // break
                                if (t >= stopY)
                                    break;

                                // for each kernel column
                                for (j = 0; j < size; j++)
                                {
                                    jr = j - radius;
                                    t = x + jr;

                                    // skip column
                                    if (t < startX)
                                        continue;

                                    if (t < stopX)
                                    {
                                        k = kernel[i, j];
                                        p = &src[ir * srcStride + jr * pixelSize];

                                        div += k;

                                        r += k * p[RGB.R];
                                        g += k * p[RGB.G];
                                        b += k * p[RGB.B];

                                        processedKernelSize++;
                                    }
                                }
                            }

                            // check if all kernel elements were processed
                            if (processedKernelSize == kernelSize)
                            {
                                // all kernel elements are processed - we are not on the edge
                                div = divisor;
                            }
                            else
                            {
                                // we are on edge. do we need to use dynamic divisor or not?
                                if (!dynamicDivisorForEdges)
                                {
                                    // do
                                    div = divisor;
                                }
                            }

                            // check divider
                            if (div != 0)
                            {
                                r /= div;
                                g /= div;
                                b /= div;
                            }
                            r += threshold;
                            g += threshold;
                            b += threshold;

                            dst[RGB.R] = (ushort)((r > 65535) ? 65535 : ((r < 0) ? 0 : r));
                            dst[RGB.G] = (ushort)((g > 65535) ? 65535 : ((g < 0) ? 0 : g));
                            dst[RGB.B] = (ushort)((b > 65535) ? 65535 : ((b < 0) ? 0 : b));

                            // take care of alpha channel
                            if (pixelSize == 4)
                                dst[RGB.A] = src[RGB.A];
                        }
                    }
                }
            }
        }
        #endregion
    }
}
