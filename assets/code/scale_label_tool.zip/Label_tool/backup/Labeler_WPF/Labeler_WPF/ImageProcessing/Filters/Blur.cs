﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Util;

namespace ImageProcessing.Filters
{
    public sealed class Blur:BaseFilter
    {
        public Blur()
            : base(new int[,] {{ 1, 2, 3, 2, 1 },
                               { 2, 4, 5, 4, 2 },
                               { 3, 5, 6, 5, 3 },
                               { 2, 4, 5, 4, 2 },
                               { 1, 2, 3, 2, 1 } })
        {
        }
    }
}
