﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Ink;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Linq;



namespace Labeler_WPF
{
    [Serializable]
    public class scaleStrokeCollection
    {
        public StrokeCollection strokes;
        public int scale;
        public static int octave = 5;
        public static int centerX = 320;
        public static int centerY = 320;

        public scaleStrokeCollection(int scale, StrokeCollection strokes)
        {
            this.scale = scale;
            this.strokes = strokes;
        }
        public scaleStrokeCollection(int scale)
        {
            this.scale = scale;
            this.strokes = new StrokeCollection();
        }
        public scaleStrokeCollection(){}

        public void addStrokeCollection(StrokeCollection strokes)
        {
            StrokeCollection strokes2 = resizeStrokes(strokes, octave-1);
            foreach (Stroke m_stroke in strokes2)
            {
                this.strokes.Add(m_stroke);
            }
        }

        public void addStrokeCollection(StrokeCollection strokes, int displayScale)
        {
            StrokeCollection strokes2 = resizeStrokes(strokes, displayScale, octave - 1);
            foreach (Stroke m_stroke in strokes2)
            {
                this.strokes.Add(m_stroke);
            }
        }

        public void addStroke(Stroke strokeItem)
        {
            this.strokes.Add(resizeStroke(strokeItem, octave-1));
        }

        public int removeStroke(Stroke strokeItem)
        {
            //The strokeItem is sized with the image size
            if(this.strokes.Contains(strokeItem))
            {
                this.strokes.Remove(strokeItem);
                return this.strokes.Count;
            }
            else{return -1;}
        }

        public StrokeCollection resizeStrokes(int refScale)
        {
            //The resize is relative to the size of inkSketch

            StrokeCollection o_strokes = this.strokes.Clone();

            //Resize and transform
            Matrix transforMatrix = new Matrix();
            transforMatrix.ScaleAt(1 / Math.Pow(2, (octave - 1) - refScale), 1 / Math.Pow(2, (octave - 1) - refScale), centerX, centerY);
            o_strokes.Transform(transforMatrix, false);

            return o_strokes;
            
        }

        public Stroke resizeStroke(Stroke s, int refScale)
        {
            if (refScale == this.scale)
            {
                return s.Clone();
            }
            else
            {
                Stroke o_stroke = s.Clone();

                //Resize and transform
                Matrix transforMatrix = new Matrix();
                transforMatrix.ScaleAt(Math.Pow(2, refScale - this.scale), Math.Pow(2, refScale - this.scale), centerX, centerY);
                o_stroke.Transform(transforMatrix, false);

                return o_stroke;
            }
        }

        public Stroke resizeStroke(Stroke s, int displayScale, int refScale)
        {
            if (refScale == displayScale)
            {
                return s.Clone();
            }
            else
            {
                Stroke o_stroke = s.Clone();

                //Resize and transform
                Matrix transforMatrix = new Matrix();
                transforMatrix.ScaleAt(Math.Pow(2, refScale - displayScale), Math.Pow(2, refScale - displayScale), centerX, centerY);
                o_stroke.Transform(transforMatrix, false);

                return o_stroke;
            }
        }

        public StrokeCollection resizeStrokes(StrokeCollection sc, int refScale)
        {

            StrokeCollection o_strokes = sc.Clone();

            //Resize and transform
            Matrix transforMatrix = new Matrix();
            transforMatrix.ScaleAt(Math.Pow(2, refScale - this.scale), Math.Pow(2, refScale - this.scale), centerX, centerY);
            o_strokes.Transform(transforMatrix, false);

            return o_strokes;
        }

        public StrokeCollection resizeStrokes(StrokeCollection sc,int displayScale, int refScale)
        {

            StrokeCollection o_strokes = sc.Clone();

            //Resize and transform
            Matrix transforMatrix = new Matrix();
            transforMatrix.ScaleAt(Math.Pow(2, refScale - displayScale), Math.Pow(2, refScale - displayScale), centerX, centerY);
            o_strokes.Transform(transforMatrix, false);

            return o_strokes;
        }

        public static scaleStrokeCollection operator -(scaleStrokeCollection s1, scaleStrokeCollection s2)
        {
            //scaleStrokeCollection s = new scaleStrokeCollection(s1.scale, s1.strokes.Clone());
            StrokeCollection ss2 = s2.strokes.Clone();
            for (int i = 0; i < ss2.Count; i++)
            {
                //search
                for (int j = 0; j < s1.strokes.Count; j++)
                {
                    if (strokeEqual(s1.strokes[j], ss2[i]))
                    {
                        s1.strokes.RemoveAt(j);
                    }
                }
            }

            return s1;
        }

        public static bool strokeEqual(Stroke s1, Stroke s2)
        {
            if (s1.StylusPoints.Count != s2.StylusPoints.Count) return false;
            else
            {
                for (int i = 0; i < s1.StylusPoints.Count; i++)
                {
                    if (s1.StylusPoints[i] != s2.StylusPoints[i])
                        return false;
                }
            }

            return true;
        }
    }

    public class ImageScaleStrokesCollection
    {
        public static int octave = 5;
        public scaleStrokeCollection[] strokes;
        public FileInfo imgFileInfo;

        public ImageScaleStrokesCollection(FileInfo imgFileInfo)
        {
            this.imgFileInfo = imgFileInfo;
            if (!readStrokes())
            {
                strokes = new scaleStrokeCollection[octave];
                for (int i = 0; i < octave; i++)
                {
                    strokes[i] = new scaleStrokeCollection(i);
                }
            }
        }

        public ImageScaleStrokesCollection(string imgFilePath)
        {
            FileInfo imgFileInfo = new FileInfo(imgFilePath);
            this.imgFileInfo = imgFileInfo;
            if (!readStrokes())
            {
                strokes = new scaleStrokeCollection[octave];
                for (int i = 0; i < octave; i++)
                { strokes[i] = new scaleStrokeCollection(i); }
            }
        }

        public ImageScaleStrokesCollection()
        {
            strokes = new scaleStrokeCollection[octave];
            for (int i = 0; i < octave; i++)
            { strokes[i] = new scaleStrokeCollection(i); }
        }

        public void saveStrokes()
        {
            saveStrokes(imgFileInfo.FullName.Replace("jpg", "txt"));
        }

        public void saveStrokes(string savePath)
        {
            List<string> strs = new List<string>();
            strs.Add(octave.ToString());

            for (int i = 0; i < octave; i++)
            {
                strs.AddRange(formatConverter.ScaleStrokeCollection2String(this.strokes[i]));
            }
            File.WriteAllLines(savePath, strs.ToArray());
        }

        public bool readStrokes()
        {
            try
            {
                int offset = 0;
                string[] strs = File.ReadAllLines(imgFileInfo.FullName.Replace("jpg", "txt"));
                octave = Int32.Parse(strs[offset++]);

                strokes = new scaleStrokeCollection[octave];
                for (int scale = 0; scale < octave; scale++)
                {
                    this.strokes[scale] = formatConverter.string2ScaleStrokeCollection(strs, ref offset);                    
                }
                return true;
            }
            catch(Exception)
            {
                return false;
            }
        }

        public void addStrokes(StrokeCollection istrokes, int scale)
        {
            if (scale < octave && scale >= 0)
            {
                this.strokes[scale].addStrokeCollection(istrokes);

                if (scale > 0)
                {
                    for (int i = 0; i < octave; i++)
                    {
                        if (scale != i)
                        {
                            this.strokes[scale] = this.strokes[scale] - this.strokes[i];
                        }
                    }
                }
            }
        }

        public void setStrokes(StrokeCollection istrokes, int scale)
        {
            setStrokes(istrokes, scale, scale);
        }

        public void setStrokes(StrokeCollection istrokes, int scale, int displayScale)
        {
            if (scale < octave && scale >= 0)
            {
                this.strokes[scale].scale = scale;
                this.strokes[scale].strokes.Clear();
                this.strokes[scale].addStrokeCollection(istrokes, displayScale);

                for (int i = 0; i < octave; i++)
                {
                    if (scale != i)
                    {
                        this.strokes[scale] = this.strokes[scale] - this.strokes[i];
                    }
                }
            }
        }

        public void setStrokesNoResizing(StrokeCollection istrokes, int scale)
        {
            if (scale < octave && scale >= 0)
            {
                this.strokes[scale] = new scaleStrokeCollection(scale, istrokes);
            }
        }

        public void addStroke(Stroke istroke, int scale)
        {
            if (scale < octave && scale >= 0)
            {
                this.strokes[scale].addStroke(istroke);
            }
        }

        public StrokeCollection generateStrokeDisplay(int scale)
        {
            StrokeCollection strokesDisplay = new StrokeCollection();

            for (int i = 0; i <= scale; i++)
            {
                if (this.strokes[i].strokes.Count > 0)
                {
                    strokesDisplay.Add(this.strokes[i].resizeStrokes(scale));
                }
            }

            return strokesDisplay;
        }

        public StrokeCollection generateStrokeDisplaySingleScale(int scale)
        {
            return generateStrokeDisplaySingleScale(scale, scale);
        }

        public StrokeCollection generateStrokeDisplaySingleScale(int scale, int displayScale)
        {
            StrokeCollection strokesDisplay = new StrokeCollection();

            strokesDisplay.Add(this.strokes[scale].resizeStrokes(displayScale));

            return strokesDisplay;
        }
    }

    public class formatConverter
    {
        //-----------------------------------------------------------------------------------------------------------
        //ScaleNumber
        //Loop:
        //+++++Scale
        //+++++Number of strokes in each scale
        //+++++Each stroke is a seperate line: PointsNum : X1,Y1,X2,Y2,...
        //End Loop;
        //-----------------------------------------------------------------------------------------------------------
        public static string Stroke2String(Stroke s)
        {
            //Header
            string str = s.StylusPoints.Count.ToString() + " : ";

            //Points
            foreach (StylusPoint p in s.StylusPoints)
            {
                str += p.X.ToString() + "," + p.Y.ToString() + ",";
            }
            return str;
        }

        public static Stroke string2Stroke(string str)
        {
            char[] splitor = {':',','};
            string[] splitedArray = str.Split(splitor);

            //header
            int pointNum = Int32.Parse(splitedArray[0].Trim());
            StylusPointCollection pCollection = new StylusPointCollection();

            for(int i = 1;i<pointNum;i++)
            {
                double x = Double.Parse(splitedArray[2*i-1].Trim());
                double y = Double.Parse(splitedArray[2*i].Trim());

                StylusPoint p = new StylusPoint(x,y);
                pCollection.Add(p);
            }

            return (new Stroke(pCollection));
        }

        public static string[] StrokeCollection2String(StrokeCollection sc)
        {
            string[] strs = new string[sc.Count + 1];
            strs[0] = sc.Count.ToString();

            for(int i=0;i<sc.Count;i++)
            {
                strs[i+1] = Stroke2String(sc[i]);
            }
            return strs;
        }

        public static StrokeCollection string2StrokeCollection(string[] strs, ref int offset)
        {
            //First read the stroke number
            int sNum = Int32.Parse(strs[offset++].Trim());
            StrokeCollection sc = new StrokeCollection();
            for (int i = 0; i < sNum; i++)
            {
                sc.Add(string2Stroke(strs[offset++]));
            }

            return sc;
        }

        public static string[] ScaleStrokeCollection2String(scaleStrokeCollection ssc)
        {
            string[] strs = new string[ssc.strokes.Count + 2];

            strs[0] = ssc.scale.ToString();
            string[] strs2 = StrokeCollection2String(ssc.strokes);
            for (int i = 0; i <= ssc.strokes.Count; i++)
            {
                strs[i + 1] = strs2[i];
            }

            return strs;
        }

        public static scaleStrokeCollection string2ScaleStrokeCollection(string[] strs, ref int offset)
        {
            int scale = Int32.Parse(strs[offset++].Trim());

            StrokeCollection sc = string2StrokeCollection(strs, ref offset);

            return (new scaleStrokeCollection(scale, sc));
        }
    }
}
