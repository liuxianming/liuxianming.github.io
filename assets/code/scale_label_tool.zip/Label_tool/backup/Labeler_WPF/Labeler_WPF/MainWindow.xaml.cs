﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Ink;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using ImageProcessing;
using Util;

namespace Labeler_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private static int DEFAULT_DIST_THRESH = 2;

        private List<FileInfo> imgFileList;
        private string imgDBPath = @"D:\user\v-xialiu\Label_tool\Labeler_WPF\Labeler_WPF\imageDB\";
        //private string imgDBPath = @".\imageDB\";
        private int imgCount = 0;

        private int imgIndex = -1;
        private int octave = 5;
        private int scaleIndex = 0;
        private Bitmap[] octaveList;
        private bool isEditMode = false;
        private bool isPointSelecive = false;
        private int scaleIndex_editMode = 0;
        //private int strokeIndex_editMode = 0;
        private Stroke selectedStroke;
        private int selectedStrokeIndex = -1;
        private StylusPoint selectedPoint;
        private int selectedPointIndex = -1;

        private bool suggestMode = false;

        private int suggestStrokeIndex = -1;

        private EdgeSuggestion.CEdgeSuggestion suggetor;

        private ImageScaleStrokesCollection imgStrokes;

        private bool isDragMode = false;           //This flag is used in MouseMove handler

        private void clearImgIndex()
        {
            this.imgIndex = -1;
        }

        public MainWindow()
        {
            InitializeComponent();
            readConf();
            this.imgCount = this.initialImgDB(this.imgDBPath);
            scale_slider.Maximum = this.octave - 1;

            image1.VerticalAlignment = System.Windows.VerticalAlignment.Center;
            image1.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;

            inkSketch.DefaultDrawingAttributes.Color = System.Windows.Media.Color.FromRgb(255, 0, 0);

            checkbox_editing.IsChecked = false;
            this.button_nextImage.Content = "Begin Labeling";
            scale_slider.IsEnabled = false;
            this.buttonScaleInc.IsEnabled = false;
            this.buttonScaleDec.IsEnabled = false;

            this.editPanel.Visibility = System.Windows.Visibility.Hidden;

            buttonConfirmSingleStroke.Visibility = System.Windows.Visibility.Hidden;
            buttonConfirmSelectionStroke.Visibility = System.Windows.Visibility.Hidden;

            suggestionCanvas.Visibility = System.Windows.Visibility.Hidden;
        }

        private bool readConf()
        {
            string confPath = @".\conf.ini";

            try
            {
                CfgInfoLoader cfg = new CfgInfoLoader(confPath);

                this.imgDBPath = cfg.m_ParaValueArray[(int)ParaIndex.ImageDBPath];
                this.octave = Int32.Parse(cfg.m_ParaValueArray[(int)ParaIndex.octave]);
                DEFAULT_DIST_THRESH = Int32.Parse(cfg.m_ParaValueArray[(int)ParaIndex.default_dist_thresh]);

                return true;
            }
            catch
            {
                return false;
            }
        }

        private int initialImgDB(string imgDBPath)
        {
            imgFileList = new List<FileInfo>();
            try
            {
                DirectoryInfo dir = new DirectoryInfo(imgDBPath);
                foreach (FileInfo file in dir.GetFiles("*.jpg"))
                {
                    imgFileList.Add(file);
                }
            }
            catch
            {
                return -1;
            }
            return imgFileList.Count;
        }

        private void button_nextImage_Click(object sender, RoutedEventArgs e)
        {
            if (this.imgIndex + 1 == imgCount)
            {
                button_nextImage.Content = "Finish and Close";
                imgIndex = imgIndex + 1;
            }
            else if (imgIndex == imgCount)
            {
                //quit
                //First save
                imgStrokes.saveStrokes();
                this.Close();
            }
            else
            {
                this.button_nextImage.Content = "Next Image";

                //Initialization:
                //-------------------------------------------------------------------------------------//
                //set enable
                this.buttonScaleInc.IsEnabled = true;
                this.buttonScaleDec.IsEnabled = true;

                //set edit option
                checkbox_editing.IsChecked = false;
                inkSketch.EditingMode = InkCanvasEditingMode.Ink;
                
                //set edit flag
                this.isEditMode = false;
                //-------------------------------------------------------------------------------------//
                imgIndex++;

                //Save strokes
                if (imgIndex > 0)
                {
                    imgStrokes.setStrokes(inkSketch.Strokes, scaleIndex);
                    //Save to file
                    this.imgStrokes.saveStrokes();
                }

                inkSketch.Strokes.Clear();
                editPanel.Visibility = System.Windows.Visibility.Hidden;

                //Construct ImageScaleStrokesCollection instance
                this.imgStrokes = new ImageScaleStrokesCollection(imgFileList[imgIndex]);

                showImg(imgIndex);
                this.button_nextImage.IsEnabled = false;
            }
        }

        private void showImg(int imgID)
        {
            scale_slider.Value = 0;
            scaleIndex = 0;

            Bitmap bi = (Bitmap)System.Drawing.Image.FromFile(imgFileList[imgID].FullName);

            octaveList = new Bitmap[this.octave];
            octaveList[this.octave - 1] = new Bitmap(bi, bi.Width, bi.Height);

            for (int i = 1; i < this.octave; i++)
            {
                octaveList[this.octave - i - 1] = new Bitmap(octaveList[this.octave - i], octaveList[this.octave - i].Width / 2, octaveList[this.octave - i].Height / 2);    
            }

            image1.Source = this.bitmap2Image(this.octaveList[scaleIndex]);
            image1.Visibility = System.Windows.Visibility.Visible;

            inkSketch.Strokes = imgStrokes.generateStrokeDisplay(scaleIndex);
            setColor(System.Windows.Media.Color.FromRgb(255, 0, 0), inkSketch);

            //Set the bounds of inkSketch
            setBound();

            suggetor = new EdgeSuggestion.CEdgeSuggestion(imgFileList[imgID].FullName, scaleIndex);
        }

        private void scale_slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            int newScale = Convert.ToInt32(scale_slider.Value);

            if (newScale == this.octave - 1)
            {
                this.button_nextImage.IsEnabled = true;
            }
            else
            {
                this.button_nextImage.IsEnabled = false;
            }

            //Save strokes first
            imgStrokes.setStrokes(inkSketch.Strokes, this.scaleIndex);
            imgStrokes.saveStrokes();

            //display image on new resolution
            image1.Source = bitmap2Image(this.octaveList[newScale]);

            suggetor = new EdgeSuggestion.CEdgeSuggestion(imgFileList[imgIndex].FullName, newScale);

            setBound();

            if (newScale > this.scaleIndex)
            {
                //Firstly set the checkbox into "editing mode"
                this.checkbox_editing.IsChecked = true;

                inkSketch.Strokes = imgStrokes.generateStrokeDisplaySingleScale(0, newScale);
                setColor(System.Windows.Media.Color.FromArgb(80,0,0,255), inkSketch);

                //Entering the "editing mode"
                //-----------------------------------------------------------------------------------//
                //In the editing mode, the labeling results on the previous scale is firstly modified//
                //in the new scale, and then confirm until all the strokes are completed             //
                //-----------------------------------------------------------------------------------//

                editPanel.Visibility = System.Windows.Visibility.Visible;
                editInstructionText.Text = "Please modify(move or redraw) each stroke on the new resolution";

                //unenable the whole panel
                LabelPanel.IsEnabled = false;
                LabelPanel.Visibility = System.Windows.Visibility.Hidden;
                //button_nextImage.IsEnabled = false;

                this.isEditMode = true;
                scaleIndex_editMode = 0;

                inkSketch.EditingMode = InkCanvasEditingMode.Select;
            }
            else
            {
                //display strokes

                inkSketch.Strokes = imgStrokes.generateStrokeDisplay(newScale);
                setColor(System.Windows.Media.Color.FromRgb(255, 0, 0), inkSketch);
                inkSketch.Visibility = System.Windows.Visibility.Visible;
            }

            scaleIndex = newScale;
        }

        private void setBound()
        {
            Rect m_rect = new Rect(new System.Windows.Point(image1.Width/2 - image1.Source.Width/2, image1.Height/2 - image1.Source.Height/2), new System.Windows.Size(Convert.ToInt32(image1.Source.Width), Convert.ToInt32(image1.Source.Height))); 
            RectangleGeometry m_RG = new RectangleGeometry(m_rect);
            inkSketch.Clip = m_RG;
        }

        private BitmapImage bitmap2Image(Bitmap Bi)
        {
            MemoryStream ms = new MemoryStream();
            Bi.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
            BitmapImage bImage = new BitmapImage();
            bImage.BeginInit();
            bImage.StreamSource = new MemoryStream(ms.ToArray());
            bImage.EndInit();
            ms.Dispose();

            return bImage;
        }

        #region Edit Option
        private void ButtonPen_Click(object sender, RoutedEventArgs e)
        {
            inkSketch.EditingMode = InkCanvasEditingMode.Ink;
        }

        private void ButtonCLear_Click(object sender, RoutedEventArgs e)
        {
            inkSketch.Strokes.Clear();
        }

        private void ButtonDelete_Click(object sender, RoutedEventArgs e)
        {
            inkSketch.EditingMode = InkCanvasEditingMode.EraseByStroke;
        }

        private void button_back_click(object sender, RoutedEventArgs e)
        {
            //withdraw the last stroke
            if (inkSketch.Strokes.Count > 0)
            {
                inkSketch.Strokes.RemoveAt(inkSketch.Strokes.Count - 1);
            }
        }
        #endregion


        #region Edit Strokes

        #endregion

        private void setColor(System.Windows.Media.Color color, System.Windows.Controls.InkCanvas IC)
        {
            foreach (Stroke s in IC.Strokes)
            {
                s.DrawingAttributes.Color = color;
            }
        }

        private void buttonScaleInc_Click(object sender, RoutedEventArgs e)
        {
            if(this.scale_slider.Value < this.scale_slider.Maximum)
                this.scale_slider.Value = this.scale_slider.Value + 1;
        }

        private void buttonScaleDec_Click(object sender, RoutedEventArgs e)
        {
            if (this.scale_slider.Value > 0)
                this.scale_slider.Value = this.scale_slider.Value - 1;
        }

        private void editConfirmButton_Click(object sender, RoutedEventArgs e)
        {
            if (this.isEditMode)
            {
                //Save first
                //Save the strokes on dispalyScale = scaleIndex, scale = scaleIndex_editMode;
                imgStrokes.setStrokes(inkSketch.Strokes, scaleIndex_editMode, scaleIndex);
                imgStrokes.saveStrokes();

                //Finally, add scaleIndex_editMode
                scaleIndex_editMode++;
                if (scaleIndex_editMode == scaleIndex)
                {
                    //exit editMode
                    exitEditMode();
                }
                else
                {
                    inkSketch.Strokes.Clear();
                    inkSketch.Strokes = imgStrokes.generateStrokeDisplaySingleScale(scaleIndex_editMode, scaleIndex);

                    setColor(System.Windows.Media.Color.FromArgb(80, 0, 0, 255), inkSketch);
                }
            }
        }

        private void exitEditMode()
        {
            LabelPanel.IsEnabled = true;
            LabelPanel.Visibility = System.Windows.Visibility.Visible;
            checkbox_editing.IsChecked = false;
            editPanel.Visibility = System.Windows.Visibility.Hidden;

            inkSketch.EditingMode = InkCanvasEditingMode.Ink;

            //show labeled strokes
            inkSketch.Strokes = imgStrokes.generateStrokeDisplay(scaleIndex);
            setColor(System.Windows.Media.Color.FromRgb(255, 255, 0), inkSketch);

            isEditMode = false;
        }

        private void editSelect_Click(object sender, RoutedEventArgs e)
        {
            inkSketch.EditingMode = InkCanvasEditingMode.Select;
        }

        private void inkSketch_SelectionChanging(object sender, InkCanvasSelectionChangingEventArgs e)
        {
            //Get the stroke
            if (selectedStrokeIndex >= 0)
            {
                //Set and Save
                imgStrokes.setStrokes(inkSketch.Strokes, scaleIndex_editMode, scaleIndex);
                imgStrokes.saveStrokes();

                inkSketch.Strokes[selectedStrokeIndex].DrawingAttributes.Color = System.Windows.Media.Color.FromRgb(255, 0, 0);
            }

            StrokeCollection sc = e.GetSelectedStrokes();

            if (sc.Count > 0)
            {

                foreach (Stroke aStroke in inkSketch.Strokes)
                {
                    if (sc.Contains(aStroke))
                    {
                        this.selectedStrokeIndex = inkSketch.Strokes.IndexOf(aStroke);

                        //enable single stroke confirm button
                        buttonConfirmSingleStroke.Visibility = System.Windows.Visibility.Visible;
                        buttonConfirmSelectionStroke.Visibility = System.Windows.Visibility.Visible;

                        selectedStroke = aStroke;
                        //The selecting stroke is in "green"
                        inkSketch.Strokes[selectedStrokeIndex].DrawingAttributes.Color = System.Windows.Media.Color.FromRgb(255,0,255);
                        selectedStroke.DrawingAttributes.IsHighlighter = true;

                        editConfirmButton.IsEnabled = false;
                    }
                }
            }
            else
            {

            }
        }

        #region "Overrided Mouse Event Handler"
        private void onMouseDown_pointSelective(object sender, MouseButtonEventArgs e)
        {
            if (!isPointSelecive)
            {
                return;
            }

            //Set flag
            isDragMode = true;

            //1. Find the selected point within all the points on selectedStroke
            //First capture the click point position
            System.Windows.Point p = e.GetPosition(inkSketch);

            selectedStroke = inkSketch.Strokes[selectedStrokeIndex];

            List<double> distList = new List<double>();
            for (int i = 0; i < selectedStroke.StylusPoints.Count; i++)
            {
                distList.Add(Math.Abs(p.X - selectedStroke.StylusPoints[i].X) + Math.Abs(p.Y - selectedStroke.StylusPoints[i].Y));
            }

            selectedPointIndex = distList.IndexOf(distList.Min());
            this.selectedPoint = selectedStroke.StylusPoints[selectedPointIndex];
        }

        private void inkSketch_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragMode)
            {
                //In the drag mode
                //Get the release position
                System.Windows.Point releasePoint = e.GetPosition(inkSketch);

                //update the stroke
                inkSketch.Strokes[selectedStrokeIndex].StylusPoints[selectedPointIndex] = new StylusPoint(releasePoint.X, releasePoint.Y);
            }
        }

        private void onMouseUp_pointSelective(object sender, MouseButtonEventArgs e)
        {
            if (isDragMode)
            {
                suggestStrokeIndex = selectedStrokeIndex;
                suggestStroke();
                isDragMode = false;
            }
        }
        #endregion

        private void buttonConfirmSingleStroke_Click(object sender, RoutedEventArgs e)
        {
            inkSketch.EditingMode = InkCanvasEditingMode.Select;

            inkSketch.Strokes[selectedStrokeIndex].DrawingAttributes.Color = System.Windows.Media.Color.FromRgb(255, 0, 0);

            buttonConfirmSingleStroke.Visibility = System.Windows.Visibility.Hidden;
            buttonConfirmSelectionStroke.Visibility = System.Windows.Visibility.Hidden;

            isPointSelecive = false;

            inkSketch.Select(new StrokeCollection());
            
            //Set and Save
            imgStrokes.setStrokes(inkSketch.Strokes, scaleIndex_editMode, scaleIndex);
            imgStrokes.saveStrokes();

            editConfirmButton.IsEnabled = true;

            //Clear selection
            this.selectedStroke = null;
            this.selectedPointIndex = -1;
            this.selectedStrokeIndex = -1;

            //make editing button visiable
            editOptionPanel_EditMode.Visibility = System.Windows.Visibility.Visible;
        }

        private void buttonConfirmSelectionStroke_Click(object sender, RoutedEventArgs e)
        {
            //set flag to enable point-wise editing
            isPointSelecive = true;

            inkSketch.Select(new StrokeCollection());

            inkSketch.Strokes[selectedStrokeIndex].DrawingAttributes.Color = System.Windows.Media.Color.FromRgb(255,0,255);

            inkSketch.EditingMode = InkCanvasEditingMode.None;
            editConfirmButton.IsEnabled = false;

            //make editing button hidden
            editOptionPanel_EditMode.Visibility = System.Windows.Visibility.Hidden;
        }

        private void editDeleteButton_Click(object sender, RoutedEventArgs e)
        {
            inkSketch.EditingMode = InkCanvasEditingMode.EraseByStroke;
        }

        private void inkSketch_StrokeCollected(object sender, InkCanvasStrokeCollectedEventArgs e)
        {
            if (!suggestMode)
            {
                //Suggest a better candidate stroke according to the latest added ink stroke
                Stroke newAddedStroke = e.Stroke;
                this.suggestStrokeIndex = inkSketch.Strokes.IndexOf(newAddedStroke);
                //At this time, the "newAddedStroke" is already added to inkSketch.Strokes
                suggestMode = true;
                suggestStroke();
            }
        }

        #region "Suggest Strokes"
        private void suggestStroke()
        {
            Stroke s = inkSketch.Strokes[suggestStrokeIndex];
            if (suggetor != null)
            {
                float[] weights = { 1.0f, 2.5f };

                Stroke suggestedStroke = suggetor.suggestStroke(pos_ink2img(s), DEFAULT_DIST_THRESH * (int)(Math.Pow(2.0,scaleIndex/2.0)), weights);
                Stroke inkSuggestedStroke = pos_img2ink(suggestedStroke);

                inkSuggestedStroke.DrawingAttributes.Color = System.Windows.Media.Color.FromRgb(200, 200, 200);
                inkSketch.Strokes.Add(inkSuggestedStroke);

                //next, need to confirm
                //set visibility
                suggestionCanvas.Visibility = System.Windows.Visibility.Visible;

                editPanel.Visibility = System.Windows.Visibility.Hidden;
                LabelPanel.Visibility = System.Windows.Visibility.Hidden;

                inkSketch.IsEnabled = false;
            }
        }
        #endregion

        #region "Position transformation"
        private Stroke pos_ink2img(Stroke s)
        {
            int imgHeight = octaveList[scaleIndex].Height;
            int imgWidth = octaveList[scaleIndex].Width;

            StylusPointCollection tranedPointCollection = new StylusPointCollection();
            for (int i = 0; i < s.StylusPoints.Count; i++)
            {
                StylusPoint p = s.StylusPoints[i];
                
                double newX = p.X - inkSketch.Width / 2 + imgWidth / 2;
                double newY = p.Y - inkSketch.Height / 2 + imgHeight / 2;

                //First validate the point p
                if (newX >= imgWidth || newY >= imgHeight)
                {
                    //this point is bad
                    s.StylusPoints.RemoveAt(i);
                    continue;
                }
                tranedPointCollection.Add(new StylusPoint(newX, newY));
            }
                
            return new Stroke(tranedPointCollection);
        }

        private Stroke pos_img2ink(Stroke s)
        {
            int imgHeight = octaveList[scaleIndex].Height;
            int imgWidth = octaveList[scaleIndex].Width;
            
            StylusPointCollection tranedPointCollection = new StylusPointCollection();
            foreach (StylusPoint p in s.StylusPoints)
            {
                double newX = p.X - imgWidth / 2 + inkSketch.Width / 2;
                double newY = p.Y - imgHeight / 2 + inkSketch.Height / 2;
                tranedPointCollection.Add(new StylusPoint(newX, newY));
            }

            return new Stroke(tranedPointCollection);
        }
        #endregion

        #region "Reload Eventhandlers"
        //Reload the event handler to active the self-constructed handler functions
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            inkSketch.AddHandler(InkCanvas.MouseLeftButtonDownEvent, new MouseButtonEventHandler(onMouseDown_pointSelective), true);
            inkSketch.AddHandler(InkCanvas.MouseLeftButtonUpEvent, new MouseButtonEventHandler(onMouseUp_pointSelective), true);
            inkSketch.AddHandler(InkCanvas.MouseMoveEvent, new MouseEventHandler(inkSketch_MouseMove), true);
            inkSketch.AddHandler(InkCanvas.StrokeCollectedEvent, new InkCanvasStrokeCollectedEventHandler(inkSketch_StrokeCollected), true);
        }
        #endregion

        #region "Suggestion Confirmation"
        private void buttonGoodSuggestion_Click(object sender, RoutedEventArgs e)
        {
            //preserve the suggested stroke
            inkSketch.Strokes[inkSketch.Strokes.Count - 1].DrawingAttributes.Color = inkSketch.Strokes[suggestStrokeIndex].DrawingAttributes.Color;
            inkSketch.Strokes.RemoveAt(suggestStrokeIndex);

            //set visibility
            if (isEditMode)
            {
                editPanel.Visibility = System.Windows.Visibility.Visible;
                LabelPanel.Visibility = System.Windows.Visibility.Hidden;
            }
            else
            {
                editPanel.Visibility = System.Windows.Visibility.Hidden;
                LabelPanel.Visibility = System.Windows.Visibility.Visible;
            }
            suggestionCanvas.Visibility = System.Windows.Visibility.Hidden;

            inkSketch.IsEnabled = true;

            suggestMode = false;
        }

        private void buttonBadSuggestion_Click(object sender, RoutedEventArgs e)
        {
            //preserve the original stroke
            inkSketch.Strokes.RemoveAt(inkSketch.Strokes.Count - 1);

            //set visibility
            if (isEditMode)
            {
                editPanel.Visibility = System.Windows.Visibility.Visible;
            }
            else
            {
                editPanel.Visibility = System.Windows.Visibility.Hidden;
            }
            LabelPanel.Visibility = System.Windows.Visibility.Visible;
            suggestionCanvas.Visibility = System.Windows.Visibility.Hidden;
            inkSketch.IsEnabled = true;

            suggestMode = false;
        }
        #endregion

        private void inkSketch_SelectionMovedandResized(object sender, EventArgs e)
        {
            
        }
    }
}
