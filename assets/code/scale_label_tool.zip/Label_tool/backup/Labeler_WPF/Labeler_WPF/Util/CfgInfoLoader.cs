﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;


namespace Util
{
    enum ParaIndex
    {
        ImageDBPath = 0,
        octave,
        default_dist_thresh
    };
   
    class CfgInfoLoader
    {
        public string[] m_ParaValueArray;
        private string[] m_CommentList = {"#", "%"};

        public CfgInfoLoader(string cfgFilePath)
        {
            string[] allCfgInfo = File.ReadAllLines(cfgFilePath);
            m_ParaValueArray = new string[Enum.GetValues(typeof(ParaIndex)).Length];
            foreach (string cfgLine in allCfgInfo)
            {
                ParsePara(cfgLine);
            }
        }

        private void ParsePara(string cfgLine)
        {
            if (m_CommentList.Contains(cfgLine[0].ToString()))
            {
                return;
            }
            else
            {
                string[] words = cfgLine.Split('=');
                
                if (words.Length < 2)
                {
                    return;
                }

                Type paraIndexType = typeof(ParaIndex);
                foreach (string paraName in Enum.GetNames(paraIndexType))
                {                    
                    if (words[0].Trim() == paraName)
                    {
                        m_ParaValueArray[(int)Enum.Parse(paraIndexType, paraName)] = words[1].Trim();
                        break;
                    }
                }
            }
        }
    }
}
