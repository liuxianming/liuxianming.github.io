﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Ink;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Linq;

namespace Labeler_WPF
{

    /// <summary>
    /// Serialize and Deserialize
    /// </summary>
    public class FormatterHelper
    {
        public static byte[] Serialize(object obj)
        {
            BinaryFormatter binaryF = new BinaryFormatter();
            MemoryStream ms = new MemoryStream(1024 * 10);

            binaryF.Serialize(ms, obj);
            ms.Seek(0, SeekOrigin.Begin);

            byte[] buffer = new byte[(int)ms.Length];
            ms.Read(buffer, 0, buffer.Length);
            ms.Close();

            return buffer;
        }

        public static object Deserialize(byte[] buffer)
        {
            BinaryFormatter binaryF = new BinaryFormatter();
            MemoryStream ms = new MemoryStream(buffer, 0, buffer.Length, false);

            object obj = binaryF.Deserialize(ms);
            ms.Close();

            return obj;
        }
    }

    /// <summary>
    /// This class is used to convert between StrokeCollections and XML
    /// </summary>
    public class StrokeXMLConverter
    {
        public XElement StrokestoXAML(StrokeCollection mystrokes)
        {
            //this method uses LINQ to XML
            //be sure to add the namespace to each element in order to load back
            //into a new StrokeCollection later with the XAMLReader

            string xmlnsString = "http://schemas.microsoft.com/client/2007";

            XNamespace xmlns = xmlnsString;
            XElement XMLStrokes = new XElement(xmlns + "StrokeCollection",
                new XAttribute("xmlns", xmlnsString));

            //create stroke, then add to collection element      
            XElement mystroke;
            foreach (Stroke s in mystrokes)
            {
                mystroke = new XElement(xmlns + "Stroke",
                  new XElement(xmlns + "Stroke.DrawingAttributes",
                    new XElement(xmlns + "DrawingAttributes",
                       new XAttribute("Color", s.DrawingAttributes.Color),
                       new XAttribute("Width", s.DrawingAttributes.Width),
                       new XAttribute("Height", s.DrawingAttributes.Height))));

                //create points separately then add to mystroke XElement
                XElement myPoints = new XElement(xmlns + "Stroke.StylusPoints");
                foreach (StylusPoint sp in s.StylusPoints)
                {
                    XElement mypoint = new XElement(xmlns + "StylusPoint",
                      new XAttribute("X", sp.X.ToString()),
                      new XAttribute("Y", sp.Y.ToString()));
                    //add the new point to the points collection of the stroke
                    myPoints.Add(mypoint);
                }
                //add the new points collection to the stroke
                mystroke.Add(myPoints);
                //add the stroke to the collection
                XMLStrokes.Add(mystroke);
            }
            return XMLStrokes;
        }

        private StrokeCollection CreateWPFStrokeCollectionfromXAML(string XAMLStrokes)
        {
            //because namespace was used to create this
            // (for Silverlight to reuse the XAML),
            //you need to insert the namesace into the Descendent's parameter

            var xmlElem = XElement.Parse(XAMLStrokes);
            XNamespace xmlns = xmlElem.GetDefaultNamespace();
            StrokeCollection objStrokes = new StrokeCollection();
            //Query the XAML to extract the Strokes
            var strokes = from s in xmlElem.Descendants(xmlns + "Stroke") select s;
            foreach (XElement strokeNodeElement in strokes)
            {
                //query the stroke to extract its StylusPoints
                var points = from p
                  in strokeNodeElement.Descendants(xmlns + "StylusPoint")
                             select p;
                //create Stylus points collection from point element values
                StylusPointCollection pointData =
                  new System.Windows.Input.StylusPointCollection();
                foreach (XElement pointElement in points)
                {
                    double Xpoint = Convert.ToDouble(pointElement.Attribute("X").Value);
                    double Ypoint = Convert.ToDouble(pointElement.Attribute("Y").Value);
                    pointData.Add(new StylusPoint(Xpoint, Ypoint));
                }
                //create a new Stroke from the StylusPointCollection
                System.Windows.Ink.Stroke newstroke = new
                   System.Windows.Ink.Stroke(pointData);
                //add the new stroke to the StrokeCollection
                objStrokes.Add(newstroke);
            }
            return objStrokes;
        }
    }
}